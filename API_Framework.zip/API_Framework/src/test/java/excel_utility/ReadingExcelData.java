package excel_utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadingExcelData {
	
	public ArrayList<String> excelRead(String testCaseName, String sheetName) throws IOException
	{
		
		ArrayList<String> al = new ArrayList<String>();
		FileInputStream fis = new FileInputStream("C://Users//E5659257//OneDrive - FIS//Desktop//Practical//DDTSheet.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		int sheetCount = workbook.getNumberOfSheets();
		for(int i =0;i<sheetCount;i++)
		{
	
			if(workbook.getSheetName(i).equalsIgnoreCase(sheetName))
			{
				XSSFSheet sheet = workbook.getSheetAt(i);
				Iterator<Row> rows = sheet.iterator();
				Row firstRow =	rows.next();
				Iterator<Cell> cell = firstRow.cellIterator();
				int k =0;
				int desiredTestCaseCell = 0;
				while(cell.hasNext())
				{
				Cell value = cell.next();
				if(value.getStringCellValue().equalsIgnoreCase("TestCases"))
				{
					desiredTestCaseCell =k;					
				}
				k++;
				}
				while(rows.hasNext())
				{
					Row r = rows.next();
					if(r.getCell(desiredTestCaseCell).getStringCellValue().equalsIgnoreCase(testCaseName));
					{
						Iterator<Cell> cellData = r.cellIterator();
						while(cellData.hasNext())
						{
							Cell c = cellData.next();
							if(c.getCellTypeEnum() == CellType.STRING)
							{
							al.add(c.getStringCellValue());
							}
							else 
							{
							al.add(NumberToTextConverter.toText(c.getNumericCellValue()));
							}
							
						}
					}
				
				}
			
			}	
			
		}
		return al;
	}

}
