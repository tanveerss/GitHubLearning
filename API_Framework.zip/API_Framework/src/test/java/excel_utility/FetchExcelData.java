package excel_utility;

import java.io.IOException;
import java.util.ArrayList;

public class FetchExcelData {

	public static void main(String[] args) throws IOException {
		ReadingExcelData RED = new ReadingExcelData();
		ArrayList data = RED.excelRead("Login","TestData");
		System.out.println(data.get(0));
		System.out.println(data.get(1));
		System.out.println(data.get(2));
		System.out.println(data.get(3));
	}

}
