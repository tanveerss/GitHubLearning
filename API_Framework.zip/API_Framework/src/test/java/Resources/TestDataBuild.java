package Resources;

import java.util.ArrayList;
import java.util.List;

import PostPlaceWithPOJO.Serialization;
import PostPlaceWithPOJO.location;

public class TestDataBuild {

	public Serialization addPlacePayload(String setName, String setLanguage, String setWebsite)
	{	
	
		Serialization s = new Serialization();
		s.setAccuracy(50);
		s.setAddress("Jammu");
		s.setLanguage(setLanguage);
		s.setName(setName);
		s.setWebsite(setWebsite);
		location loc =new location();
		loc.setLat(255.455);
		loc.setLng(122.45);
		s.setLocation(loc);
		s.setPhone_number("91 56200 565 5555");
		List<String> l = new ArrayList<String>();
		l.add("Shoe");
		l.add("gherkins");
		s.setTypes(l);
		
		return s;
	}
	
	public String deletePlacePayload(String place_id)
	{
		
		return "{\r\n \"place_id\":\""+place_id+"\"\r\n}";   
	}
	
}
