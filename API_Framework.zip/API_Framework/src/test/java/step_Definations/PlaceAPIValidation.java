package step_Definations;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.*;
import java.io.FileNotFoundException;
import java.io.IOException;

import Resources.APIResources;
import Resources.TestDataBuild;
import Resources.Utils;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class PlaceAPIValidation extends Utils  {
	
	RequestSpecification request;
	Response response;
	TestDataBuild data = new TestDataBuild();
	static String place_id;
	
	@Given("Add place Payload with {string} {string} {string}")
	public void add_place_payload_with(String setName, String setLanguage, String setWebsite) throws IOException {	
		
		request  = given().spec(requestSpecification())
	    .body(data.addPlacePayload(setName,setLanguage,setWebsite));	
	}
	
	@When("users calls {string} API with {string} http request")
	public void users_calls_api_with_post_http_request(String resource , String method) {
		
		APIResources API_Resources = APIResources.valueOf(resource);
	//	ResponseSpecification resspec = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
		if(method.equalsIgnoreCase("GET"))
		response = request.when().get(API_Resources.resources());
		else if(method.equalsIgnoreCase("POST"))
			response = request.when().post(API_Resources.resources());
	}
	
	@Then("API call is success with status code {int}")
	public void api_call_is_success_with_status_code(Integer int1) {
		assertEquals(response.getStatusCode(),200);
	 
	}
	@Then("{string} in response body is {string}")
	public void in_response_body_is(String keyValue, String statusvalue) {
		assertEquals(getJSONValues(response,keyValue),statusvalue);	  
	}
	
	@Then("verify {string} using {string} fetch place_id from post API call")
	public void verify_place_id_created_maps_to_using(String expectedName, String resource) throws IOException {
		place_id = getJSONValues(response,"place_id");
		request  = given().spec(requestSpecification()).queryParam("place_id", place_id);
		users_calls_api_with_post_http_request(resource,"GET");
		String actualName = getJSONValues(response,"name");
		assertEquals(actualName,expectedName);
	}
	
	@Given("We have Delete API payload")
	public void we_have_delete_api_payload() throws IOException {
		request  = given().spec(requestSpecification()).body(data.deletePlacePayload(place_id));   
	   
	}
	

}
