package step_Definations;

import java.io.IOException;

import io.cucumber.java.Before;

public class Hooks {
	
	@Before("@DeletePlace")
	public void beforeScenario() throws IOException
	{
		PlaceAPIValidation PAV = new PlaceAPIValidation();
		if(PlaceAPIValidation.place_id == null)
		{
		PAV.add_place_payload_with("Sheety","French","sheety.com");	
		PAV.users_calls_api_with_post_http_request("AddPlaceAPI", "POST");
		PAV.verify_place_id_created_maps_to_using("Sheety", "GetPlaceAPI");
		}
	}

}
